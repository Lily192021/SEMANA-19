package com.example.semana19

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlin.android.synthetic.main.activity_main2.*

class Main2Activity: AppCompatActivity() {

    fun onCreate(savedInstanceState: Bundle?,) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        //RECIBIMOS EL VALOR DE LA PRIMERA ACTIVIDAD
        //CREAMOS UNA VARIABLE
        val bundle =intent.extras
        tvMOSTRARLOSDATOS.text =bundle?.getString("dt")

    }

    fun VOLVER(view: View) {
     intent = Intent(this@Main2Activity,MainActivity::class.java)
        startActivity(intent)

    }


    }

}