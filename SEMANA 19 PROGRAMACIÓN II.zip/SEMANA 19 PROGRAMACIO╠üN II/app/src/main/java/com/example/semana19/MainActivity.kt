package com.example.semana19

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlin.android.synthetic.main.activity_main*

 class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

     fun SIGUIENTE(view: View) {
         //Toast.makeText(this,"Clic en el Botón", Toast.LENGTH_LONG).show()
         //CREAR UNA CONSTANTE NO MODIFICABLE COMO INTENT
         val intent = Intent(this@MainActivity,Main2Activity::class.java)
         //VARIABLE QUE PUEDE SUFRIR CAMBIOS O RECIBIR DIFERENTES VALORES

         // A ESTA VARIABLE LE ASIGNAMOS EL VALOR A ENVIAR
         var datos :String =etDATOS.text.toString()
         // CREAR UNA CONSTANTE DE TIPO BUNDLE
         val b :Bundle = Bundle()
         // LE AGREGAMOS EL VALOR DE LA VARIABLE "DATOS" PARA SER ENVIADO

         // PUEDES AGREGAR MAS DE UN DATO, HACIENDO UNA LINEA POR CADA DATO
         b.putString("dt",datos)
         // CARGAMOS A LA INTENT EL DATO A ENVIAR
         intent.putExtras(b)
         //EJECUTAMOS LA INTENT
         startActivity(intent)


     }
 }